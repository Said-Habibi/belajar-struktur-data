package Praktikum11.Tugas.QueueLinkedList;

public class Node {
    int data;
    Node next;

    public Node(int data){
        this.data = data;
        this.next = null;
    }
}
